/**
 * @author: zhaojianfeng
 * @date: ${DATE} ${TIME}
 */
public class ${NAME} {
}
