/**
 * @author: zhaojianfeng
 * @date: ${DATE} ${TIME}
 */
public interface ${NAME} {
}
